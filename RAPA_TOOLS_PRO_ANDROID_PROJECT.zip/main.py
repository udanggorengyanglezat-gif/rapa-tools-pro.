# RAPA TOOLS PRO - Kivy app for Android / Pydroid 3
# Install Kivy in Pydroid 3 before running this file.
# Default password: 1234

import ast
import operator
import json
import os
from datetime import datetime

from kivy.app import App
from kivy.clock import Clock
from kivy.animation import Animation
from kivy.metrics import dp, sp
from kivy.core.window import Window
from kivy.utils import get_color_from_hex
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.widget import Widget
from kivy.uix.popup import Popup

APP_NAME = "RAPA TOOLS PRO"
CONFIG_FILE = "rapa_config.json"
NOTES_FILE = "rapa_notes.json"

BG = get_color_from_hex("#0B1020")
PANEL = get_color_from_hex("#151E33")
PANEL2 = get_color_from_hex("#1C2944")
BLUE = get_color_from_hex("#3987FF")
CYAN = get_color_from_hex("#48D7E8")
WHITE = get_color_from_hex("#F4F7FF")
MUTED = get_color_from_hex("#9EABC5")
GREEN = get_color_from_hex("#39C98A")
RED = get_color_from_hex("#F16C7A")


def load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def safe_calculate(expression):
    allowed = {
        ast.Add: operator.add, ast.Sub: operator.sub,
        ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod,
        ast.USub: operator.neg, ast.UAdd: operator.pos,
    }

    def walk(node):
        if isinstance(node, ast.Expression):
            return walk(node.body)
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in allowed:
            left, right = walk(node.left), walk(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 8:
                raise ValueError("Pangkat terlalu besar")
            return allowed[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in allowed:
            return allowed[type(node.op)](walk(node.operand))
        raise ValueError("Operasi tidak didukung")

    tree = ast.parse(expression, mode="eval")
    result = walk(tree)
    if abs(result) > 1e100:
        raise ValueError("Hasil terlalu besar")
    return result


class RapaButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ""
        self.background_down = ""
        self.background_color = BLUE
        self.color = WHITE
        self.bold = True
        self.font_size = sp(15)
        self.size_hint_y = None
        self.height = dp(50)
        self.border = (0, 0, 0, 0)

    def on_press(self):
        Animation(background_color=PANEL2, duration=0.08).start(self)

    def on_release(self):
        Animation(background_color=BLUE, duration=0.12).start(self)


class RapaApp(App):
    def build(self):
        self.title = APP_NAME
        Window.clearcolor = BG
        self.config_data = load_json(CONFIG_FILE, {"password": "1234"})
        self.notes = load_json(NOTES_FILE, [])
        self.clock_event = None
        self.counter_value = 0
        self.root_box = BoxLayout(orientation="vertical", padding=dp(16), spacing=dp(12))
        self.show_login()
        return self.root_box

    def label(self, text, size=16, color=WHITE, bold=False, height=None, halign="left"):
        w = Label(
            text=text, font_size=sp(size), color=color, bold=bold,
            halign=halign, valign="middle", size_hint_y=None,
            height=dp(height) if height else dp(34)
        )
        w.bind(size=lambda inst, val: setattr(inst, "text_size", (val[0], None)))
        return w

    def panel(self, padding=14, spacing=10):
        box = BoxLayout(
            orientation="vertical", padding=dp(padding), spacing=dp(spacing),
            size_hint_y=None
        )
        box.bind(minimum_height=box.setter("height"))
        from kivy.graphics import Color, RoundedRectangle
        with box.canvas.before:
            Color(*PANEL)
            box.bg_rect = RoundedRectangle(pos=box.pos, size=box.size, radius=[dp(18)])
        box.bind(pos=lambda inst, val: setattr(inst.bg_rect, "pos", val),
                 size=lambda inst, val: setattr(inst.bg_rect, "size", val))
        return box

    def clear(self):
        if self.clock_event:
            self.clock_event.cancel()
            self.clock_event = None
        self.root_box.clear_widgets()

    def add_header(self, subtitle="TOOLS AND UTILITIES"):
        self.root_box.add_widget(self.label("[b]RΛPA[/b]  [color=48D7E8]PRO[/color]", 27, WHITE, True, 42))
        self.root_box.add_widget(self.label(subtitle, 10, MUTED, True, 22))

    def add_back(self):
        btn = RapaButton(text="←  KEMBALI")
        btn.bind(on_release=lambda *_: self.show_home())
        self.root_box.add_widget(btn)

    def show_login(self):
        self.clear()
        self.root_box.add_widget(Widget())
        self.root_box.add_widget(self.label("[b]RΛPA[/b]", 42, WHITE, True, 58, "center"))
        self.root_box.add_widget(self.label("TOOLS PRO  •  ANDROID EDITION", 12, CYAN, True, 30, "center"))
        card = self.panel(18, 12)
        card.add_widget(self.label("SELAMAT DATANG", 19, WHITE, True, 36))
        card.add_widget(self.label("Masukkan password untuk membuka aplikasi.", 12, MUTED, False, 30))
        self.password_input = TextInput(
            hint_text="Password", password=True, multiline=False,
            size_hint_y=None, height=dp(48), font_size=sp(17),
            background_normal="", background_active="",
            background_color=PANEL2, foreground_color=WHITE,
            cursor_color=CYAN, padding=[dp(12), dp(12)]
        )
        card.add_widget(self.password_input)
        login = RapaButton(text="MASUK")
        login.bind(on_release=self.check_password)
        card.add_widget(login)
        self.login_message = self.label("", 12, RED, False, 24)
        card.add_widget(self.login_message)
        self.root_box.add_widget(card)
        self.root_box.add_widget(Widget())
        self.root_box.add_widget(self.label("Default password: 1234", 11, MUTED, False, 24, "center"))

    def check_password(self, *_):
        if self.password_input.text == str(self.config_data.get("password", "1234")):
            self.show_home()
        else:
            self.login_message.text = "Password salah. Coba lagi."

    def show_home(self):
        self.clear()
        self.add_header("DASHBOARD  •  PILIH FITUR")
        scroll = ScrollView(do_scroll_x=False)
        content = GridLayout(cols=2, spacing=dp(10), size_hint_y=None, padding=[0, dp(4)])
        content.bind(minimum_height=content.setter("height"))
        items = [
            ("◷\nJAM DIGITAL", self.clock_page),
            ("＋ − × ÷\nKALKULATOR", self.calculator_page),
            ("⇄\nKONVERTER", self.converter_page),
            ("▤\nCATATAN", self.notes_page),
            ("◎\nPENGHITUNG", self.counter_page),
            ("⚙\nPENGATURAN", self.settings_page),
        ]
        for title, callback in items:
            btn = RapaButton(text=title, height=dp(105), font_size=sp(16))
            btn.bind(on_release=lambda instance, cb=callback: cb())
            content.add_widget(btn)
        scroll.add_widget(content)
        self.root_box.add_widget(scroll)
        footer = self.label("RAPA TOOLS PRO  |  SIMPLE • FAST • USEFUL", 9, MUTED, False, 24, "center")
        self.root_box.add_widget(footer)

    def clock_page(self):
        self.clear()
        self.add_header("JAM DIGITAL  •  REAL TIME")
        self.root_box.add_widget(Widget())
        card = self.panel(18, 14)
        card.add_widget(self.label("WAKTU SEKARANG", 12, CYAN, True, 28, "center"))
        self.time_label = self.label("--:--:--", 44, WHITE, True, 82, "center")
        card.add_widget(self.time_label)
        self.date_label = self.label("Memuat tanggal...", 15, MUTED, False, 34, "center")
        card.add_widget(self.date_label)
        card.add_widget(self.label("FORMAT 24 JAM", 10, GREEN, True, 25, "center"))
        self.root_box.add_widget(card)
        self.root_box.add_widget(Widget())
        self.add_back()
        self.update_clock(0)
        self.clock_event = Clock.schedule_interval(self.update_clock, 1)

    def update_clock(self, dt):
        if hasattr(self, "time_label"):
            now = datetime.now()
            self.time_label.text = now.strftime("%H:%M:%S")
            days = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"]
            months = ["Januari", "Februari", "Maret", "April", "Mei", "Juni",
                      "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
            self.date_label.text = f"{days[now.weekday()]}, {now.day} {months[now.month-1]} {now.year}"

    def calculator_page(self):
        self.clear()
        self.add_header("KALKULATOR  •  HITUNGAN DASAR")
        card = self.panel()
        self.calc_input = TextInput(
            hint_text="Contoh: (12+8)*3", multiline=False, size_hint_y=None,
            height=dp(54), font_size=sp(20), background_normal="",
            background_active="", background_color=PANEL2,
            foreground_color=WHITE, cursor_color=CYAN, padding=dp(12)
        )
        card.add_widget(self.calc_input)
        self.calc_result = self.label("Hasil akan muncul di sini", 17, CYAN, True, 42)
        card.add_widget(self.calc_result)
        go = RapaButton(text="HITUNG")
        go.bind(on_release=self.calculate)
        card.add_widget(go)
        self.root_box.add_widget(card)
        self.root_box.add_widget(self.label("Gunakan +  -  *  /  %  dan tanda kurung.", 11, MUTED, False, 34))
        self.root_box.add_widget(Widget())
        self.add_back()

    def calculate(self, *_):
        try:
            result = safe_calculate(self.calc_input.text.strip())
            self.calc_result.text = f"Hasil: {result:g}" if isinstance(result, float) else f"Hasil: {result}"
        except Exception:
            self.calc_result.text = "Periksa kembali rumus yang dimasukkan."

    def converter_page(self):
        self.clear()
        self.add_header("KONVERTER  •  SATUAN")
        card = self.panel()
        self.convert_value = TextInput(
            hint_text="Masukkan angka", multiline=False, input_filter="float",
            size_hint_y=None, height=dp(50), font_size=sp(18),
            background_normal="", background_active="", background_color=PANEL2,
            foreground_color=WHITE, cursor_color=CYAN, padding=dp(12)
        )
        card.add_widget(self.convert_value)
        self.convert_mode = TextInput(
            text="meter ke kilometer", multiline=False, size_hint_y=None,
            height=dp(48), font_size=sp(15), background_normal="",
            background_active="", background_color=PANEL2,
            foreground_color=WHITE, cursor_color=CYAN, padding=dp(12)
        )
        card.add_widget(self.convert_mode)
        card.add_widget(self.label("Pilihan: meter ke kilometer | kilometer ke meter | meter ke cm | kg ke gram | gram ke kg", 10, MUTED, False, 48))
        result_btn = RapaButton(text="KONVERSI")
        result_btn.bind(on_release=self.convert_units)
        card.add_widget(result_btn)
        self.convert_result = self.label("Hasil konversi tampil di sini", 17, CYAN, True, 42)
        card.add_widget(self.convert_result)
        self.root_box.add_widget(card)
        self.root_box.add_widget(Widget())
        self.add_back()

    def convert_units(self, *_):
        try:
            value = float(self.convert_value.text)
            mode = self.convert_mode.text.strip().lower()
            conversions = {
                "meter ke kilometer": value / 1000,
                "kilometer ke meter": value * 1000,
                "meter ke cm": value * 100,
                "kg ke gram": value * 1000,
                "gram ke kg": value / 1000,
            }
            if mode not in conversions:
                raise ValueError()
            self.convert_result.text = f"Hasil: {conversions[mode]:g}"
        except Exception:
            self.convert_result.text = "Angka atau pilihan konversi belum sesuai."

    def notes_page(self):
        self.clear()
        self.add_header("CATATAN  •  TERSIMPAN DI HP")
        self.note_input = TextInput(
            hint_text="Tulis catatan di sini...", multiline=True,
            size_hint_y=0.36, font_size=sp(16), background_normal="",
            background_active="", background_color=PANEL2,
            foreground_color=WHITE, cursor_color=CYAN, padding=dp(12)
        )
        self.root_box.add_widget(self.note_input)
        save_btn = RapaButton(text="SIMPAN CATATAN")
        save_btn.bind(on_release=self.save_note)
        self.root_box.add_widget(save_btn)
        self.notes_status = self.label("", 11, GREEN, False, 24)
        self.root_box.add_widget(self.notes_status)
        self.root_box.add_widget(self.label("CATATAN TERSIMPAN", 12, CYAN, True, 28))
        self.notes_list = BoxLayout(orientation="vertical", spacing=dp(6), size_hint_y=None)
        self.notes_list.bind(minimum_height=self.notes_list.setter("height"))
        sc = ScrollView(do_scroll_x=False)
        sc.add_widget(self.notes_list)
        self.root_box.add_widget(sc)
        self.refresh_notes()
        self.add_back()

    def save_note(self, *_):
        text_value = self.note_input.text.strip()
        if text_value:
            self.notes.insert(0, {"text": text_value, "date": datetime.now().strftime("%d/%m/%Y %H:%M")})
            save_json(NOTES_FILE, self.notes)
            self.note_input.text = ""
            self.notes_status.text = "Catatan berhasil disimpan."
            self.refresh_notes()
        else:
            self.notes_status.text = "Isi catatan terlebih dahulu."

    def refresh_notes(self):
        self.notes_list.clear_widgets()
        if not self.notes:
            self.notes_list.add_widget(self.label("Belum ada catatan.", 12, MUTED, False, 34))
        for index, note in enumerate(self.notes):
            row = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(4), size_hint_y=None)
            row.height = dp(76)
            row.add_widget(self.label(note.get("text", ""), 13, WHITE, False, 42))
            row.add_widget(self.label(note.get("date", ""), 10, MUTED, False, 20))
            self.notes_list.add_widget(row)

    def counter_page(self):
        self.clear()
        self.add_header("PENGHITUNG  •  COUNTER")
        self.counter_value = 0
        self.counter_label = self.label("0", 54, WHITE, True, 100, "center")
        self.root_box.add_widget(Widget())
        self.root_box.add_widget(self.counter_label)
        plus = RapaButton(text="+ TAMBAH")
        plus.bind(on_release=lambda *_: self.change_counter(1))
        minus = RapaButton(text="− KURANGI")
        minus.bind(on_release=lambda *_: self.change_counter(-1))
        reset = RapaButton(text="RESET")
        reset.bind(on_release=lambda *_: self.change_counter(0, True))
        self.root_box.add_widget(plus)
        self.root_box.add_widget(minus)
        self.root_box.add_widget(reset)
        self.root_box.add_widget(Widget())
        self.add_back()

    def change_counter(self, amount, reset=False):
        self.counter_value = 0 if reset else self.counter_value + amount
        self.counter_label.text = str(self.counter_value)

    def settings_page(self):
        self.clear()
        self.add_header("PENGATURAN  •  KEAMANAN")
        card = self.panel()
        card.add_widget(self.label("GANTI PASSWORD", 15, WHITE, True, 32))
        self.old_password = TextInput(
            hint_text="Password lama", password=True, multiline=False,
            size_hint_y=None, height=dp(48), background_normal="",
            background_active="", background_color=PANEL2,
            foreground_color=WHITE, padding=dp(12)
        )
        self.new_password = TextInput(
            hint_text="Password baru", password=True, multiline=False,
            size_hint_y=None, height=dp(48), background_normal="",
            background_active="", background_color=PANEL2,
            foreground_color=WHITE, padding=dp(12)
        )
        card.add_widget(self.old_password)
        card.add_widget(self.new_password)
        change = RapaButton(text="SIMPAN PASSWORD BARU")
        change.bind(on_release=self.change_password)
        card.add_widget(change)
        self.settings_status = self.label("", 11, GREEN, False, 26)
        card.add_widget(self.settings_status)
        self.root_box.add_widget(card)
        self.root_box.add_widget(self.label("Password awal aplikasi: 1234", 11, MUTED, False, 28))
        self.root_box.add_widget(Widget())
        self.add_back()

    def change_password(self, *_):
        old = self.old_password.text
        new = self.new_password.text.strip()
        if old != str(self.config_data.get("password", "1234")):
            self.settings_status.text = "Password lama tidak cocok."
            self.settings_status.color = RED
        elif len(new) < 4:
            self.settings_status.text = "Password baru minimal 4 karakter."
            self.settings_status.color = RED
        else:
            self.config_data["password"] = new
            save_json(CONFIG_FILE, self.config_data)
            self.settings_status.text = "Password berhasil diubah."
            self.settings_status.color = GREEN
            self.old_password.text = ""
            self.new_password.text = ""

    def on_stop(self):
        if self.clock_event:
            self.clock_event.cancel()
            self.clock_event = None


if __name__ == "__main__":
    RapaApp().run()
