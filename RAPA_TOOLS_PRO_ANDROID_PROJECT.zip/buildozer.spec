[app]

title = RAPA TOOLS PRO
package.name = rapatools
package.domain = org.rapa

source.dir = .
source.include_exts = py,json,png,jpg,kv
version = 1.0.0

requirements = python3,kivy
orientation = portrait
fullscreen = 0

# Build for common Android devices.
android.archs = arm64-v8a, armeabi-v7a
android.api = 35
android.minapi = 23
android.accept_sdk_license = True

# No special permissions are required by this app.
