# RAPA TOOLS PRO - Android APK project

## Build APK using only an Android phone

This project is configured to build in GitHub Actions, so you do not need a PC.
You will need a GitHub account and an internet connection.

1. Extract this ZIP on your phone.
2. Open github.com in Chrome and sign in.
3. Create a new repository, for example `rapa-tools-pro`.
4. Upload the project files and folders from this ZIP. Make sure `main.py`,
   `buildozer.spec`, and `.github/workflows/build.yml` are at the repository root
   and in the correct folder structure.
5. Open the repository's **Actions** tab.
6. Choose **Build RAPA TOOLS PRO APK** and tap **Run workflow**.
7. Wait for the workflow to finish successfully.
8. Open the completed workflow run, find **Artifacts**, and download
   `RAPA-TOOLS-PRO-APK`.
9. Extract the downloaded artifact ZIP. It contains the APK.
10. Tap the APK to install. Android may ask you to allow installs from your
    browser or file manager; only allow it for the file you built yourself.

## Notes

- The first build can take a while because Android build tools are downloaded.
- This workflow creates a debug APK for testing, not a Play Store release.
- Default app password: `1234`. Change it from the app's Settings screen.
- Notes and password configuration are stored in app files. Reinstalling or
  clearing app data may reset them.
- If the build fails, open the failed workflow run and share the last error
  lines so the project can be fixed.
